package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signupServlet
 */
@WebServlet("/signupServlet")
public class signupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public signupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String user=request.getParameter("user");
		String pass=request.getParameter("pass");
		String cpass=request.getParameter("cpass");
		String intro=request.getParameter("intro");
		String hobby=request.getParameter("hobby");
		
		PreparedStatement stmt;
		Statement stmt1;
		ResultSet rs;
		Connection con;
		RequestDispatcher rd;
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/registration","root","root"); //we got connection
			String sql="insert into User_registration(fname,lname,email,user,pass) values(?,?,?,?,?)";
			
			stmt=con.prepareStatement(sql);
			stmt.setString(1,fname);
			stmt.setString(2,lname);
			stmt.setString(3,email);
			stmt.setString(4,user);
			stmt.setString(5,pass);
			
			int row=stmt.executeUpdate();
			//*****************************************************************
			if(row>0)
			{
				String sql1="select id from User_registration where user='"+user+"'";
				stmt1=con.createStatement();
				int id = 0;
				rs=stmt.executeQuery(sql1);
				
				while(rs.next())
				{
				     id=rs.getInt("id");
				}
				
				System.out.println(id);
				//**************************************************
				
				String sql2="insert into user_details(id,intro,hobby) values(?,?,?)";
				
				stmt=con.prepareStatement(sql2);
				stmt.setInt(1,id);
				stmt.setString(2,intro);
				stmt.setString(3,hobby);
				
				int row1=stmt.executeUpdate();
				
				if(row1>0)
				{
					request.setAttribute("status","User Registration Successfull.");
					rd=request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				}
				
			}
			
			else
			{
				request.setAttribute("status","Failed to sign up....! Please Try again.");
				rd=request.getRequestDispatcher("signup.jsp");
				rd.forward(request, response);		
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
